'use strict';
import { firebaseConfig } from './firebase-config.js';
const $=id=>document.getElementById(id);
const horses=[
{name:'イクイノックス',rating:100,style:'先行',speed:100,stamina:99,kick:99,start:94,mud:92,best:[1800,2500]},
{name:'ディープインパクト',rating:100,style:'追込',speed:100,stamina:98,kick:100,start:88,mud:90,best:[1800,3200]},
{name:'オルフェーヴル',rating:99,style:'追込',speed:98,stamina:100,kick:99,start:83,mud:96,best:[2000,3200]},
{name:'アーモンドアイ',rating:100,style:'差し',speed:100,stamina:94,kick:100,start:93,mud:90,best:[1600,2400]},
{name:'キタサンブラック',rating:99,style:'逃げ',speed:96,stamina:100,kick:94,start:99,mud:93,best:[2000,3200]},
{name:'コントレイル',rating:98,style:'差し',speed:98,stamina:97,kick:99,start:91,mud:89,best:[1800,3000]},
{name:'ジェンティルドンナ',rating:98,style:'先行',speed:98,stamina:98,kick:97,start:95,mud:92,best:[1800,2500]},
{name:'ウオッカ',rating:98,style:'差し',speed:99,stamina:93,kick:99,start:90,mud:90,best:[1600,2400]},
{name:'ロードカナロア',rating:98,style:'先行',speed:100,stamina:80,kick:99,start:98,mud:94,best:[1000,1600]},
{name:'エルコンドルパサー',rating:98,style:'先行',speed:97,stamina:98,kick:97,start:95,mud:97,best:[1600,2500]},
{name:'テイエムオペラオー',rating:98,style:'先行',speed:95,stamina:100,kick:96,start:96,mud:95,best:[2000,3200]},
{name:'ナリタブライアン',rating:98,style:'先行',speed:98,stamina:99,kick:98,start:94,mud:94,best:[1800,3200]},
{name:'シンボリルドルフ',rating:98,style:'先行',speed:97,stamina:100,kick:96,start:97,mud:93,best:[2000,3200]},
{name:'ミスターシービー',rating:96,style:'追込',speed:96,stamina:98,kick:99,start:82,mud:91,best:[1800,3200]},
{name:'トウカイテイオー',rating:97,style:'先行',speed:98,stamina:96,kick:98,start:94,mud:91,best:[1800,2500]},
{name:'スペシャルウィーク',rating:97,style:'差し',speed:96,stamina:99,kick:97,start:89,mud:92,best:[2000,3200]},
{name:'グラスワンダー',rating:97,style:'先行',speed:98,stamina:96,kick:98,start:94,mud:95,best:[1600,2500]},
{name:'サイレンススズカ',rating:97,style:'逃げ',speed:100,stamina:91,kick:96,start:100,mud:92,best:[1600,2200]},
{name:'メジロマックイーン',rating:97,style:'先行',speed:94,stamina:100,kick:93,start:96,mud:96,best:[2200,3200]},
{name:'ゴールドシップ',rating:97,style:'追込',speed:94,stamina:100,kick:97,start:77,mud:100,best:[2200,3200]},
{name:'ブエナビスタ',rating:97,style:'差し',speed:98,stamina:96,kick:100,start:88,mud:91,best:[1600,2500]},
{name:'ジャスタウェイ',rating:97,style:'差し',speed:100,stamina:91,kick:100,start:88,mud:93,best:[1600,2200]},
{name:'モーリス',rating:97,style:'先行',speed:100,stamina:88,kick:99,start:95,mud:94,best:[1400,2000]},
{name:'グランアレグリア',rating:98,style:'差し',speed:100,stamina:83,kick:100,start:91,mud:91,best:[1200,2000]},
{name:'ドウデュース',rating:97,style:'差し',speed:98,stamina:97,kick:100,start:87,mud:90,best:[1600,2500]},
{name:'リバティアイランド',rating:96,style:'差し',speed:98,stamina:96,kick:99,start:89,mud:90,best:[1600,2500]},
{name:'ソダシ',rating:95,style:'先行',speed:97,stamina:89,kick:95,start:97,mud:94,best:[1400,2000]},
{name:'デアリングタクト',rating:96,style:'差し',speed:96,stamina:96,kick:98,start:89,mud:95,best:[1600,2500]},
{name:'ラヴズオンリーユー',rating:96,style:'差し',speed:96,stamina:96,kick:98,start:90,mud:91,best:[1800,2500]},
{name:'クロノジェネシス',rating:97,style:'先行',speed:96,stamina:99,kick:96,start:95,mud:100,best:[1800,2500]},
{name:'リスグラシュー',rating:97,style:'差し',speed:97,stamina:98,kick:99,start:88,mud:95,best:[1600,2500]},
{name:'エフフォーリア',rating:96,style:'先行',speed:97,stamina:97,kick:97,start:94,mud:90,best:[1800,2500]},
{name:'タイトルホルダー',rating:96,style:'逃げ',speed:94,stamina:100,kick:91,start:100,mud:96,best:[2200,3200]},
{name:'サトノダイヤモンド',rating:96,style:'差し',speed:95,stamina:99,kick:97,start:89,mud:91,best:[2000,3200]},
{name:'シュヴァルグラン',rating:95,style:'先行',speed:93,stamina:100,kick:94,start:93,mud:93,best:[2200,3200]},
{name:'エピファネイア',rating:96,style:'先行',speed:96,stamina:99,kick:96,start:94,mud:96,best:[2000,3200]},
{name:'キズナ',rating:95,style:'差し',speed:96,stamina:97,kick:98,start:88,mud:92,best:[1800,2500]},
{name:'キングカメハメハ',rating:97,style:'先行',speed:99,stamina:94,kick:98,start:96,mud:93,best:[1600,2400]},
{name:'ハーツクライ',rating:96,style:'差し',speed:96,stamina:99,kick:98,start:88,mud:94,best:[2000,3200]},
{name:'ゼンノロブロイ',rating:95,style:'先行',speed:95,stamina:99,kick:95,start:94,mud:91,best:[2000,3200]},
{name:'アドマイヤムーン',rating:95,style:'差し',speed:97,stamina:95,kick:98,start:89,mud:94,best:[1600,2400]},
{name:'ダイワスカーレット',rating:97,style:'逃げ',speed:98,stamina:96,kick:96,start:100,mud:94,best:[1600,2500]},
{name:'メイショウサムソン',rating:95,style:'先行',speed:94,stamina:100,kick:93,start:96,mud:98,best:[2000,3200]},
{name:'ヴィクトワールピサ',rating:96,style:'先行',speed:96,stamina:97,kick:96,start:95,mud:96,best:[1800,2500]},
{name:'エイシンフラッシュ',rating:95,style:'差し',speed:96,stamina:95,kick:99,start:88,mud:93,best:[1800,2500]},
{name:'フェノーメノ',rating:95,style:'先行',speed:94,stamina:100,kick:94,start:94,mud:91,best:[2200,3200]},
{name:'ジャングルポケット',rating:95,style:'差し',speed:96,stamina:98,kick:98,start:88,mud:93,best:[2000,2500]},
{name:'マンハッタンカフェ',rating:95,style:'差し',speed:93,stamina:100,kick:96,start:86,mud:92,best:[2200,3200]},
{name:'アグネスタキオン',rating:96,style:'先行',speed:99,stamina:94,kick:99,start:95,mud:93,best:[1600,2400]},
{name:'クロフネ',rating:97,style:'先行',speed:99,stamina:92,kick:98,start:97,mud:100,best:[1400,2100]},
{name:'アグネスデジタル',rating:96,style:'差し',speed:98,stamina:90,kick:98,start:90,mud:100,best:[1200,2000]},
{name:'カネヒキリ',rating:95,style:'先行',speed:96,stamina:94,kick:94,start:96,mud:100,best:[1400,2100]},
{name:'ヴァーミリアン',rating:95,style:'先行',speed:95,stamina:97,kick:94,start:95,mud:100,best:[1600,2400]},
{name:'ホッコータルマエ',rating:95,style:'先行',speed:94,stamina:98,kick:92,start:96,mud:100,best:[1600,2400]},
{name:'コパノリッキー',rating:95,style:'逃げ',speed:97,stamina:94,kick:91,start:100,mud:99,best:[1400,2100]},
{name:'クリソベリル',rating:96,style:'先行',speed:96,stamina:96,kick:95,start:96,mud:100,best:[1600,2100]},
{name:'レモンポップ',rating:97,style:'先行',speed:99,stamina:88,kick:97,start:98,mud:100,best:[1200,1800]},
{name:'フォーエバーヤング',rating:98,style:'先行',speed:98,stamina:96,kick:98,start:97,mud:100,best:[1600,2100]},
{name:'オジュウチョウサン',rating:95,style:'先行',speed:89,stamina:100,kick:91,start:96,mud:100,best:[2500,4300]},
{name:'タイキシャトル',rating:97,style:'先行',speed:100,stamina:86,kick:99,start:98,mud:96,best:[1200,1600]},
{name:'サクラバクシンオー',rating:96,style:'逃げ',speed:100,stamina:78,kick:96,start:100,mud:92,best:[1000,1400]},
{name:'デュランダル',rating:95,style:'追込',speed:99,stamina:81,kick:100,start:78,mud:90,best:[1000,1600]},
{name:'カレンチャン',rating:95,style:'先行',speed:99,stamina:79,kick:96,start:98,mud:96,best:[1000,1400]},
{name:'ストレイトガール',rating:94,style:'差し',speed:98,stamina:80,kick:98,start:91,mud:94,best:[1000,1600]},
{name:'ミッキーアイル',rating:94,style:'逃げ',speed:99,stamina:82,kick:94,start:100,mud:91,best:[1200,1600]},
{name:'ファインニードル',rating:94,style:'先行',speed:98,stamina:80,kick:95,start:97,mud:97,best:[1000,1400]},
{name:'ダノンスマッシュ',rating:94,style:'先行',speed:98,stamina:81,kick:96,start:96,mud:93,best:[1000,1400]},
{name:'ナランフレグ',rating:92,style:'追込',speed:96,stamina:82,kick:99,start:79,mud:97,best:[1000,1400]},
{name:'ナムラクレア',rating:95,style:'差し',speed:99,stamina:80,kick:99,start:92,mud:97,best:[1000,1400]},
{name:'サトノレーヴ',rating:95,style:'先行',speed:99,stamina:80,kick:96,start:98,mud:92,best:[1000,1400]},
{name:'ノースフライト',rating:95,style:'先行',speed:99,stamina:86,kick:98,start:96,mud:91,best:[1400,1800]},
{name:'ニホンピロウイナー',rating:95,style:'先行',speed:99,stamina:84,kick:96,start:97,mud:92,best:[1400,1800]},
{name:'ダイワメジャー',rating:96,style:'先行',speed:98,stamina:91,kick:95,start:98,mud:95,best:[1400,2000]},
{name:'ハットトリック',rating:94,style:'差し',speed:98,stamina:86,kick:99,start:87,mud:90,best:[1400,1800]},
{name:'ロゴタイプ',rating:94,style:'先行',speed:96,stamina:92,kick:94,start:97,mud:94,best:[1600,2000]},
{name:'インディチャンプ',rating:95,style:'差し',speed:99,stamina:87,kick:98,start:90,mud:91,best:[1400,1800]},
{name:'ソングライン',rating:96,style:'差し',speed:99,stamina:88,kick:99,start:89,mud:94,best:[1400,1800]},
{name:'セリフォス',rating:95,style:'差し',speed:99,stamina:86,kick:99,start:88,mud:90,best:[1400,1800]},
{name:'ジャンタルマンタル',rating:96,style:'先行',speed:100,stamina:87,kick:97,start:97,mud:89,best:[1400,1800]},
{name:'ソウルラッシュ',rating:95,style:'差し',speed:98,stamina:88,kick:98,start:89,mud:100,best:[1400,1800]},
{name:'エアグルーヴ',rating:96,style:'先行',speed:97,stamina:96,kick:97,start:94,mud:92,best:[1800,2500]},
{name:'ヒシアマゾン',rating:95,style:'差し',speed:96,stamina:96,kick:98,start:88,mud:95,best:[1600,2500]},
{name:'ファビラスラフイン',rating:94,style:'先行',speed:96,stamina:94,kick:96,start:94,mud:90,best:[1600,2400]},
{name:'スティルインラブ',rating:94,style:'差し',speed:95,stamina:94,kick:97,start:89,mud:92,best:[1600,2500]},
{name:'アパパネ',rating:95,style:'先行',speed:96,stamina:94,kick:96,start:95,mud:92,best:[1600,2400]},
{name:'メジロドーベル',rating:95,style:'差し',speed:95,stamina:96,kick:97,start:87,mud:93,best:[1600,2500]},
{name:'スイープトウショウ',rating:95,style:'追込',speed:95,stamina:95,kick:100,start:80,mud:94,best:[1600,2500]},
{name:'ショウナンパンドラ',rating:95,style:'差し',speed:95,stamina:96,kick:98,start:87,mud:93,best:[1800,2500]},
{name:'マリアライト',rating:94,style:'差し',speed:93,stamina:98,kick:96,start:86,mud:100,best:[2000,2500]},
{name:'スターズオンアース',rating:96,style:'差し',speed:97,stamina:97,kick:99,start:89,mud:92,best:[1600,2500]},
{name:'チェルヴィニア',rating:95,style:'差し',speed:96,stamina:97,kick:98,start:88,mud:92,best:[1800,2500]},
{name:'レガレイラ',rating:95,style:'追込',speed:96,stamina:97,kick:100,start:83,mud:95,best:[1800,2500]},
{name:'クロワデュノール',rating:97,style:'先行',speed:98,stamina:98,kick:96,start:96,mud:90,best:[1800,2500]},
{name:'ダノンデサイル',rating:96,style:'先行',speed:96,stamina:99,kick:94,start:95,mud:92,best:[2000,2500]},
{name:'ミュージアムマイル',rating:95,style:'差し',speed:97,stamina:92,kick:98,start:90,mud:90,best:[1600,2200]},
{name:'マスカレードボール',rating:96,style:'差し',speed:96,stamina:96,kick:100,start:88,mud:89,best:[1800,2400]},
{name:'エリキング',rating:92,style:'差し',speed:93,stamina:95,kick:97,start:87,mud:91,best:[1800,2400]},
{name:'ショウヘイ',rating:92,style:'先行',speed:94,stamina:95,kick:93,start:95,mud:89,best:[1800,2400]},
{name:'メイショウタバル',rating:94,style:'逃げ',speed:96,stamina:94,kick:88,start:100,mud:97,best:[1800,2400]},
{name:'ベラジオオペラ',rating:95,style:'先行',speed:96,stamina:94,kick:95,start:97,mud:91,best:[1800,2200]},
{name:'ジャスティンパレス',rating:95,style:'差し',speed:93,stamina:100,kick:95,start:87,mud:92,best:[2200,3200]},
{name:'アーバンシック',rating:94,style:'差し',speed:92,stamina:99,kick:96,start:86,mud:91,best:[2200,3200]},
{name:'シンエンペラー',rating:94,style:'先行',speed:94,stamina:98,kick:93,start:95,mud:90,best:[2000,2500]},
{name:'ドゥレッツァ',rating:95,style:'先行',speed:94,stamina:100,kick:95,start:94,mud:91,best:[2200,3200]},
{name:'タスティエーラ',rating:94,style:'先行',speed:94,stamina:97,kick:94,start:95,mud:91,best:[2000,2500]},
{name:'シャフリヤール',rating:95,style:'差し',speed:96,stamina:96,kick:98,start:88,mud:89,best:[1800,2500]},
{name:'パンサラッサ',rating:95,style:'逃げ',speed:98,stamina:92,kick:89,start:100,mud:96,best:[1600,2200]},
{name:'ジャックドール',rating:94,style:'逃げ',speed:96,stamina:94,kick:91,start:99,mud:92,best:[1800,2200]},
{name:'ポタジェ',rating:92,style:'先行',speed:92,stamina:95,kick:91,start:95,mud:91,best:[1800,2200]},
{name:'ジオグリフ',rating:93,style:'先行',speed:94,stamina:93,kick:93,start:96,mud:96,best:[1600,2200]},
{name:'ドリームジャーニー',rating:95,style:'追込',speed:94,stamina:97,kick:100,start:78,mud:94,best:[1800,2500]},
{name:'ナカヤマフェスタ',rating:94,style:'差し',speed:93,stamina:98,kick:96,start:87,mud:98,best:[2000,2500]},
{name:'マツリダゴッホ',rating:94,style:'先行',speed:94,stamina:96,kick:93,start:96,mud:92,best:[2000,2500]},
{name:'ラッキーライラック',rating:95,style:'先行',speed:96,stamina:95,kick:96,start:95,mud:92,best:[1600,2400]},
{name:'サートゥルナーリア',rating:96,style:'先行',speed:98,stamina:94,kick:98,start:94,mud:91,best:[1800,2400]},
{name:'ワールドプレミア',rating:94,style:'差し',speed:92,stamina:100,kick:95,start:85,mud:91,best:[2200,3200]},
{name:'フィエールマン',rating:95,style:'差し',speed:93,stamina:100,kick:97,start:86,mud:92,best:[2200,3200]},
{name:'ディープボンド',rating:93,style:'先行',speed:91,stamina:100,kick:91,start:96,mud:100,best:[2200,3200]},
{name:'テーオーロイヤル',rating:94,style:'先行',speed:92,stamina:100,kick:93,start:95,mud:95,best:[2400,3400]},
{name:'ブローザホーン',rating:94,style:'差し',speed:92,stamina:99,kick:97,start:85,mud:100,best:[2200,3200]}
];
const venues={
'東京':{turn:'左',shape:'oval',straight:526},'中山':{turn:'右',shape:'oval',straight:310},'阪神':{turn:'右',shape:'oval',straight:474},'京都':{turn:'右',shape:'oval',straight:404},'中京':{turn:'左',shape:'oval',straight:413},'新潟':{turn:'左',shape:'oval',straight:659}
};
const races=[{name:'日本ダービー',distance:2400},{name:'有馬記念',distance:2500},{name:'天皇賞（秋）',distance:2000},{name:'安田記念',distance:1600},{name:'スプリンターズS',distance:1200},{name:'宝塚記念',distance:2200},{name:'天皇賞（春）',distance:3200},{name:'大阪杯',distance:2000},{name:'ジャパンC',distance:2400}];
const colors=['#fff','#111','#d92727','#2668d8','#f0ca25','#31a85a','#ef7a18','#ef93bd','#7b3eb3','#26a9b8','#795548','#8bc34a'];
function frameTextColor(number){return [2,3,4,6,8,9,11,12].includes(number)?'#fff':'#111'}
let state={wallet:10000,raceNo:1,mode:'solo',isHost:false,roomCode:null,userId:crypto.randomUUID(),field:[],race:null,venue:'東京',going:'良',betType:'win',selection:[],stake:500,adjustTarget:null,seed:1,result:[],ticketOdds:0,playerProfile:null,roomPlayers:[],currentPanel:'homePanel'};
const abilityKeys=['speed','stamina','kick','start','mud'];
const abilityLabels={speed:'スピード',stamina:'スタミナ',kick:'末脚',start:'スタート',mud:'道悪'};
let panelHistory=[],peer=null,hostConnections=new Map(),hostRoom=null,hostPeerAttempts=0;

function init(){
 Object.keys(venues).forEach(v=>$('venue').add(new Option(v,v)));
 races.forEach((r,i)=>$('racePreset').add(new Option(`${r.name} 芝${r.distance}m`,i)));
 load();bind();renderAbilityEditor('hostAbilityEditor');renderAbilityEditor('joinAbilityEditor');applyRoomFromUrl();
 $('onlineStatus').textContent=window.Peer?'オンライン機能：利用できます（主催者が開いている間有効）':'オンライン機能：通信ライブラリを読み込めませんでした';
}
function bind(){
 $('themeBtn').onclick=toggleTheme;
 $('soloModeBtn').onclick=()=>openSetup('solo');
 $('hostModeBtn').onclick=()=>show('profilePanel');
 $('joinModeBtn').onclick=()=>show('joinPanel');
 $('hostProfileNextBtn').onclick=prepareHostProfile;
 $('generateBtn').onclick=generateRace;
 $('toBetBtn').onclick=()=>{renderOdds();show('betPanel')};
 $('rerollBtn').onclick=generateRace;
 $('stake').oninput=updateTicket;$('submitBetBtn').onclick=submitBet;
 $('nextRaceBtn').onclick=()=>{state.raceNo++;state.result=[];state.selection=[];show(state.mode==='solo'?'setupPanel':'lobbyPanel')};
 $('resetBtn').onclick=()=>{state.wallet=10000;saveWallet();show('homePanel')};
 $('joinRoomBtn').onclick=joinRoom;$('hostStartBtn').onclick=hostStartOnline;
 $('copyRoomBtn').onclick=copyRoomCode;$('shareRoomBtn').onclick=shareRoomLink;
 $('winBetBtn').onclick=()=>setBetType('win');$('placeBetBtn').onclick=()=>setBetType('place');
 $('backBtn').onclick=goBack;window.addEventListener('popstate',()=>{if(state.currentPanel!=='homePanel')goBack()});
 document.addEventListener('dblclick',e=>e.preventDefault(),{passive:false});
}
function show(id,push=true){
 if(push&&state.currentPanel&&state.currentPanel!==id){panelHistory.push(state.currentPanel);try{history.pushState({panel:id},'',location.href)}catch{}}
 document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));$(id).classList.add('active');state.currentPanel=id;
 $('backBtn').hidden=['homePanel','countdownPanel','racePanel'].includes(id);
 window.scrollTo({top:0,behavior:'smooth'});
}
function goBack(){const prev=panelHistory.pop()||'homePanel';show(prev,false)}
function openSetup(mode){state.mode=mode;state.isHost=mode==='host';$('setupModeLabel').textContent=mode==='solo'?'SOLO':'ONLINE HOST';show('setupPanel')}
function load(){state.wallet=+(localStorage.getItem('umaumawallet')||10000);$('wallet').textContent=state.wallet.toLocaleString('ja-JP');document.body.dataset.theme=localStorage.getItem('kawakamitheme')||'dark';updateThemeBtn()}
function saveWallet(){localStorage.setItem('umaumawallet',state.wallet);$('wallet').textContent=state.wallet.toLocaleString('ja-JP')}
function toggleTheme(){document.body.dataset.theme=document.body.dataset.theme==='dark'?'light':'dark';localStorage.setItem('kawakamitheme',document.body.dataset.theme);updateThemeBtn()}
function updateThemeBtn(){$('themeBtn').textContent=document.body.dataset.theme==='dark'?'☀ 明るい版':'☾ かっこいい版'}
function seeded(seed){let x=seed>>>0;return()=>((x=(x*1664525+1013904223)>>>0)/4294967296)}
function defaultAllocation(){return Object.fromEntries(abilityKeys.map(k=>[k,2]))}
function renderAbilityEditor(id){const box=$(id),prefix=id.startsWith('host')?'host':'join';if(!box.dataset.values)box.dataset.values=JSON.stringify(defaultAllocation());const vals=JSON.parse(box.dataset.values);const used=Object.values(vals).reduce((a,b)=>a+b,0);box.innerHTML=`<div class="ability-summary"><b>残りポイント：${10-used}</b><span>全能力90＋配分</span></div>${abilityKeys.map(k=>`<div class="ability-row"><span>${abilityLabels[k]}</span><button data-k="${k}" data-d="-1">−</button><b>${90+vals[k]}</b><button data-k="${k}" data-d="1">＋</button></div>`).join('')}`;box.querySelectorAll('button').forEach(b=>b.onclick=()=>{const k=b.dataset.k,d=+b.dataset.d,next=vals[k]+d,total=used+d;if(next<0||next>10||total<0||total>10)return;vals[k]=next;box.dataset.values=JSON.stringify(vals);renderAbilityEditor(id)})}
function profileFrom(prefix){const box=$(`${prefix}AbilityEditor`),alloc=JSON.parse(box.dataset.values||'{}'),used=Object.values(alloc).reduce((a,b)=>a+b,0);const name=$(prefix==='host'?'hostPlayerName':'joinName').value.trim();const horseName=$(prefix==='host'?'hostHorseName':'joinHorseName').value.trim();const style=$(prefix==='host'?'hostHorseStyle':'joinHorseStyle').value;if(!name||!horseName||used!==10)return null;return {id:state.userId,name,horse:createOnlineHorse(horseName,style,alloc),ready:true}}
function createOnlineHorse(name,style,alloc){return {name,style,rating:92,speed:90+alloc.speed,stamina:90+alloc.stamina,kick:90+alloc.kick,start:90+alloc.start,mud:90+alloc.mud,best:[1200,3200],adj:{speed:0,stamina:0,kick:0,start:0,mud:0},allocation:alloc}}
function prepareHostProfile(){const p=profileFrom('host');if(!p){$('hostProfileMessage').textContent='表示名・馬名を入力し、10ポイントをすべて配分してください。';return}const raw=$('hostRoomCode').value.trim().toUpperCase().replace(/[^A-Z0-9]/g,'');if(raw&&raw.length<4){$('hostProfileMessage').textContent='ルーム名・合言葉は英数字4文字以上にしてください。';return}state.roomCode=raw||String(Math.floor(100000+Math.random()*900000));state.playerProfile=p;$('hostProfileMessage').textContent='';openSetup('host')}
function generateRace(){
 state.venue=$('venue').value;state.race=races[+$('racePreset').value];state.going=$('going').value;state.seed=Math.floor(Math.random()*2**31);
 if(state.mode==='host'){createPeerRoom();return}
 const rnd=seeded(state.seed),size=+$('fieldSize').value,pool=[...horses].sort(()=>rnd()-.5).slice(0,size);
 state.field=pool.map((h,i)=>({...h,number:i+1,adj:{speed:0,stamina:0,kick:0,start:0,mud:0}}));recalculate();drawGuide();show('guidePanel');
}
function effective(h,key){return h[key]+(h.adj?.[key]||0)}
function recalculate(){
 if(!state.field.length||!state.race)return;
 const D=state.race.distance,goingPenalty={良:0,稍重:1,重:2.5,不良:4}[state.going];
 const raw=state.field.map(h=>{const dist=h.best[0]<=D&&D<=h.best[1]?5:-Math.min(8,Math.abs(D-(D<h.best[0]?h.best[0]:h.best[1]))/150);const mud=(effective(h,'mud')-90)*goingPenalty*.08;const base=h.rating*.55+effective(h,'speed')*.18+effective(h,'stamina')*.12+effective(h,'kick')*.1+effective(h,'start')*.05+dist+mud;return Math.exp((base-90)/8)});
 const sum=raw.reduce((a,b)=>a+b,0);state.field.forEach((h,i)=>{h.winProb=raw[i]/sum;h.placeProb=Math.min(.88,Math.max(.08,h.winProb*2.35));h.winOdds=Math.max(1.3,Math.round((.82/h.winProb)*10)/10);h.placeOdds=Math.max(1.1,Math.round((.76/h.placeProb)*10)/10);h.odds=state.betType==='place'?h.placeOdds:h.winOdds});
}
function strongest(){return [...state.field].sort((a,b)=>b.winProb-a.winProb)[0]}
function probabilityText(){const h=strongest();return h?`能力予測1位：${h.number}番 ${h.name}　勝率 ${formatPct(h.winProb)}`:''}
function formatPct(v){return `${(v*100).toFixed(1)}%`}
function roundedRect(ctx,x,y,w,h,r){const rr=Math.min(r,w/2,h/2);ctx.beginPath();ctx.moveTo(x+rr,y);ctx.arcTo(x+w,y,x+w,y+h,rr);ctx.arcTo(x+w,y+h,x,y+h,rr);ctx.arcTo(x,y+h,x,y,rr);ctx.arcTo(x,y,x+w,y,rr);ctx.closePath()}
function drawCourse(ctx,markers=[],progress=0,guide=false){
 const w=ctx.canvas.width,h=ctx.canvas.height;ctx.clearRect(0,0,w,h);const startX=w*.105,goalX=w*.895,top=h*.18,bottom=h*.82,trackH=bottom-top,laneCount=Math.max(8,markers.length||10),laneH=trackH/laneCount;
 const bg=ctx.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#6eb0dd');bg.addColorStop(.38,'#9ed2ef');bg.addColorStop(.39,'#245a2c');bg.addColorStop(1,'#123b1d');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
 ctx.fillStyle='#eee4c8';roundedRect(ctx,startX-26,top-24,(goalX-startX)+52,trackH+48,28);ctx.fill();const turf=ctx.createLinearGradient(0,top,0,bottom);turf.addColorStop(0,'#4caa59');turf.addColorStop(1,'#28773b');ctx.fillStyle=turf;roundedRect(ctx,startX-14,top-13,(goalX-startX)+28,trackH+26,22);ctx.fill();ctx.strokeStyle='rgba(255,255,255,.42)';ctx.lineWidth=2;for(let i=1;i<laneCount;i++){const y=top+i*laneH;ctx.beginPath();ctx.moveTo(startX,y);ctx.lineTo(goalX,y);ctx.stroke()}
 ctx.strokeStyle='#ffe22e';ctx.lineWidth=8;ctx.beginPath();ctx.moveTo(startX,top-20);ctx.lineTo(startX,bottom+20);ctx.stroke();const cell=Math.max(10,Math.min(18,laneH*.42));for(let row=0;row<Math.ceil(trackH/cell);row++)for(let col=0;col<2;col++){ctx.fillStyle=(row+col)%2?'#111':'#fff';ctx.fillRect(goalX+col*cell-cell,top+row*cell,cell,cell)}
 if(guide){markerText(ctx,'START',startX,top-62);markerText(ctx,'GOAL',goalX,bottom+62);ctx.fillStyle='rgba(0,0,0,.62)';roundedRect(ctx,w*.25,h*.035,w*.5,h*.09,16);ctx.fill();ctx.fillStyle='#fff';ctx.font=`800 ${Math.max(22,w*.028)}px sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('START から GOAL へ一直線',w*.5,h*.08)}
 markers.forEach(m=>{const p=Math.max(0,Math.min(1,m.p)),x=startX+(goalX-startX)*p,laneIndex=Math.max(0,Math.min(laneCount-1,m.lane)),y=top+(laneIndex+.5)*laneH,r=Math.max(13,Math.min(21,w*.018)),chosen=state.selection[0]===m.number;if(chosen){ctx.save();ctx.shadowColor='#ffe36b';ctx.shadowBlur=22;ctx.fillStyle='rgba(255,226,46,.35)';ctx.beginPath();ctx.arc(x,y,r+8,0,Math.PI*2);ctx.fill();ctx.restore()}ctx.fillStyle=colors[(m.number-1)%colors.length];ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();ctx.strokeStyle=chosen?'#ffe22e':'#fff';ctx.lineWidth=chosen?6:3;ctx.stroke();ctx.fillStyle=frameTextColor(m.number);ctx.font=`900 ${Math.max(14,r*.95)}px sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(m.number,x,y)});return {startX,goalX,top,bottom}
}
function markerText(ctx,text,x,y){ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=`900 ${Math.max(22,ctx.canvas.width*.027)}px sans-serif`;ctx.lineWidth=7;ctx.strokeStyle='#101010';ctx.fillStyle='#ffe52e';ctx.strokeText(text,x,y);ctx.fillText(text,x,y)}
function drawGuide(){drawCourse($('guideCanvas').getContext('2d'),[],0,true);$('guideTitle').textContent=`${state.race.name}・${state.venue} 芝${state.race.distance}m`;$('guideDescription').textContent=`左のSTARTから右のGOALまで、約30秒かけて滑らかに進みます。能力から計算した勝率も表示します。`}
function renderOdds(){
 recalculate();$('raceNo').textContent=`第${state.raceNo}競走`;$('raceTitle').textContent=state.race.name;$('conditions').textContent=`${state.venue} 芝${state.race.distance}m・${state.going}・${venues[state.venue].turn}回り`;$('probabilityLeader').textContent=probabilityText();
 $('winBetBtn').classList.toggle('active',state.betType==='win');$('placeBetBtn').classList.toggle('active',state.betType==='place');$('betTypeTitle').textContent=state.betType==='win'?'単勝':'複勝';$('betTypeHelp').textContent=state.betType==='win'?'1着になる馬を1頭選んでください':'3着以内に入る馬を1頭選んでください';
 $('oddsBoard').innerHTML=state.field.map(h=>`<button class="horse-row ${state.selection.includes(h.number)?'selected':''}" data-n="${h.number}"><span class="number" style="background:${colors[(h.number-1)%colors.length]};color:${frameTextColor(h.number)}">${h.number}</span><span><b>${escapeHtml(h.name)}</b><span class="horse-meta">${h.style}　能力${h.rating}</span></span><span class="odds"><b>${state.betType==='win'?formatPct(h.winProb):formatPct(h.placeProb)}</b><span class="horse-meta">${state.betType==='win'?'単勝':'複勝'} ${h.odds.toFixed(1)}倍</span></span></button>`).join('');document.querySelectorAll('.horse-row').forEach(el=>el.onclick=()=>chooseHorse(+el.dataset.n));
 $('parameterPanel').hidden=state.mode!=='solo';$('rerollBtn').hidden=state.mode!=='solo';updateTicket();
}
function setBetType(type){state.betType=type;state.selection=[];state.adjustTarget=null;renderOdds();renderParamEditor()}
function chooseHorse(n){state.selection=state.selection[0]===n?[]:[n];state.adjustTarget=n;renderOdds();renderParamEditor();updateTicket()}
function renderParamEditor(){if(state.mode!=='solo')return;const h=state.field.find(x=>x.number===state.adjustTarget);if(!h){$('parameterEditor').innerHTML='<p class="note">出走馬をタップすると編集できます。</p>';return}$('parameterEditor').innerHTML=`<h4>${h.number}番 ${h.name}</h4>${abilityKeys.map(k=>`<div class="param-row"><span>${abilityLabels[k]}</span><button data-k="${k}" data-d="-1">−</button><span class="param-value">${h.adj[k]>=0?'+':''}${h.adj[k]}（${effective(h,k)}）</span><button data-k="${k}" data-d="1">＋</button></div>`).join('')}<div class="param-total ${Object.values(h.adj).reduce((a,b)=>a+b,0)===0?'ok':'bad'}">調整合計：${Object.values(h.adj).reduce((a,b)=>a+b,0)}</div>`;document.querySelectorAll('.param-row button').forEach(b=>b.onclick=()=>adjustParam(h,b.dataset.k,+b.dataset.d))}
function adjustParam(h,k,d){const next=h.adj[k]+d;if(next<-3||next>3)return;h.adj[k]=next;const total=Object.values(h.adj).reduce((a,b)=>a+b,0);if(Math.abs(total)>3){h.adj[k]-=d;return}recalculate();renderOdds();renderParamEditor();updateTicket()}
function comboOdds(){const h=state.field.find(x=>x.number===state.selection[0]);return h?(state.betType==='place'?h.placeOdds:h.winOdds):0}
function updateTicket(){state.stake=Math.max(0,+$('stake').value||0);const balanced=state.mode!=='solo'||state.field.every(h=>Object.values(h.adj||{}).reduce((a,b)=>a+b,0)===0),ok=state.selection.length===1&&state.stake>=100&&state.stake<=state.wallet&&balanced,n=state.selection[0],h=state.field.find(x=>x.number===n);$('selectedTicket').textContent=h?`${state.betType==='win'?'単勝':'複勝'} ${n}番 ${h.name}`:'未選択';state.ticketOdds=comboOdds();$('estimatedOdds').textContent=state.ticketOdds?`${state.ticketOdds.toFixed(1)}倍`:'--';$('estimatedPayout').textContent=state.ticketOdds?`${Math.floor(state.stake*state.ticketOdds).toLocaleString('ja-JP')}pt`:'--';$('submitBetBtn').disabled=!ok;$('submitBetBtn').textContent=state.mode==='solo'?'この買い目で開始':'自分の馬で待機'}
function submitBet(){if($('submitBetBtn').disabled)return;state.wallet-=state.stake;saveWallet();if(state.mode==='solo')countdownThenRace(Date.now()+3200);else show('lobbyPanel')}
function enterRaceMode(){document.body.classList.add('race-running')}
function leaveRaceMode(){document.body.classList.remove('race-running')}
function countdownThenRace(startAt){if($('countdownPanel').classList.contains('active')||$('racePanel').classList.contains('active'))return;show('countdownPanel');const tick=()=>{const left=Math.ceil((startAt-Date.now())/1000);$('countdownNumber').textContent=left>0?left:'START';if(left<=0){setTimeout(()=>{enterRaceMode();show('racePanel');runSimulation()},180);return}setTimeout(tick,80)};tick()}
function updateChosenHorseBanner(){const h=state.field.find(x=>x.number===state.selection[0]),banner=$('chosenHorseBanner');if(!h){banner.hidden=true;return}banner.hidden=false;const number=$('chosenHorseNumber');number.textContent=`${h.number}番`;number.style.background=colors[(h.number-1)%colors.length];number.style.color=frameTextColor(h.number);$('chosenHorseName').textContent=`${h.name}です`}
function runSimulation(){
 const canvas=$('track'),ctx=canvas.getContext('2d'),D=state.race.distance,rnd=seeded(state.seed),officialSecs=estimateRaceSeconds(D);let wallStart=null,previousTs=null,finished=false,lastCall=-1,stripNodes=null;
 recalculate();const runners=state.field.map((h,i)=>{const score=Math.log(Math.max(.0001,h.winProb))*15+(rnd()-.5)*7;return {...h,p:0,displayP:0,lane:i,finish:null,score,phase1:rnd()*Math.PI*2,phase2:rnd()*Math.PI*2,phase3:rnd()*Math.PI*2,amp1:.038+rnd()*.03,amp2:.021+rnd()*.025,amp3:.012+rnd()*.018}});
 const ranked=[...runners].sort((a,b)=>b.score-a.score);ranked.forEach((h,rank)=>{h.finishWall=28.72+rank*.11+rnd()*.045;h.officialFinish=officialSecs+rank*.11+rnd()*.07;h.finalRank=rank});
 $('liveTitle').textContent=state.race.name;$('liveConditions').textContent=`${state.venue} 芝${D}m・${state.going}・${probabilityText()}`;updateChosenHorseBanner();stripNodes=drawPositionStrip(runners);
 const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
 function frame(ts){
  if(wallStart===null){wallStart=ts;previousTs=ts}const dt=Math.min(.05,Math.max(.001,(ts-previousTs)/1000));previousTs=ts;const wall=(ts-wallStart)/1000;
  runners.forEach(h=>{if(h.finish!==null){h.displayP=1;h.p=1;return}const t=Math.max(0,Math.min(1,wall/h.finishWall)),envelope=Math.sin(Math.PI*t),battle=(Math.sin(t*Math.PI*8+h.phase1)*h.amp1+Math.sin(t*Math.PI*15+h.phase2)*h.amp2+Math.sin(t*Math.PI*23+h.phase3)*h.amp3)*envelope;const style=h.style==='逃げ'?.045*(1-smooth(t/.62))*envelope:h.style==='先行'?.025*(1-t)*envelope:h.style==='差し'?.042*smooth((t-.32)/.58)*envelope:.06*smooth((t-.44)/.48)*envelope;const settle=smooth((t-.80)/.20),rankTarget=((runners.length-1-h.finalRank)-(runners.length-1)/2)*.0055*settle;let target=t+battle+style+rankTarget;target=Math.min(.998,target);const smoothStep=(target-h.displayP)*(1-Math.exp(-7.5*dt));const minimumStep=dt/(h.finishWall*1.08);h.displayP+=Math.max(minimumStep,smoothStep);h.displayP=Math.max(0,Math.min(.998,h.displayP));h.p=h.displayP;if(wall>=h.finishWall){h.finish=h.officialFinish;h.displayP=1;h.p=1}});
  drawCourse(ctx,runners);updatePositionStrip(stripNodes,runners);const order=[...runners].sort((a,b)=>b.displayP-a.displayP);const leader=order[0],elapsed=Math.min(30,wall);$('elapsed').textContent=`0:${elapsed.toFixed(1).padStart(4,'0')}`;$('remaining').textContent=`${Math.max(0,Math.round(D*(1-leader.displayP)))}m`;$('speedKmh').textContent=`${(54+leader.displayP*11+Math.sin(wall*.8)*2).toFixed(1)}km/h`;$('leader').textContent=`先頭：${leader.number}番 ${leader.name}`;const call=Math.floor(elapsed/4);if(call!==lastCall){lastCall=call;$('commentary').textContent=comment(call,order,D)}
  if(runners.every(r=>r.finish!==null)||wall>30.5){if(!finished){finished=true;state.result=[...runners].sort((a,b)=>(a.finishWall-b.finishWall)||(a.number-b.number));drawCourse(ctx,state.result.map((h,i)=>({...h,p:i===0?1:Math.max(.94,.988-i*.006),displayP:i===0?1:Math.max(.94,.988-i*.006)})));setTimeout(showResult,650)}return}requestAnimationFrame(frame)
 }
 requestAnimationFrame(frame)
}
function estimateRaceSeconds(D){const table={1200:68,1600:94,2000:120,2200:132,2400:145,2500:151,3200:198};return table[D]||D/16.5}
function drawPositionStrip(runners){const strip=$('positionStrip');strip.innerHTML='';const map=new Map();runners.forEach(h=>{const el=document.createElement('div');el.className=`track-pos number${state.selection[0]===h.number?' chosen':''}`;el.textContent=h.number;el.style.background=colors[(h.number-1)%colors.length];el.style.color=frameTextColor(h.number);strip.appendChild(el);map.set(h.number,el)});updatePositionStrip(map,runners);return map}
function updatePositionStrip(nodes,runners){runners.forEach(h=>{const el=nodes.get(h.number);if(el)el.style.setProperty('--race-x',`${7+h.displayP*86}%`)})}
function comment(c,o,D){const a=o[0],b=o[1];return [`スタート！ ${a.number}番${a.name}が飛び出した！`,`序盤から激しい先行争い！ ${b.number}番が並びかける！`,`各馬が何度も位置を入れ替える大混戦！`,`中盤、${a.number}番が先頭！ 外から${b.number}番！`,`残り${Math.round(D*.45)}m！ 一気に差が縮まる！`,`直線勝負！ ${o.slice(0,4).map(x=>x.number+'番').join('・')}が横一線！`,`ゴール前！ ${a.number}番と${b.number}番、わずかな差！`,`ゴール！！ 映像どおりの着順を判定中！`][Math.min(7,c)]}
function hitTicket(){const rank=state.result.findIndex(h=>h.number===state.selection[0]);return state.betType==='place'?rank>=0&&rank<3:rank===0}
function showResult(){leaveRaceMode();show('resultPanel');const hit=hitTicket(),pay=hit?Math.floor(state.stake*state.ticketOdds):0;if(hit)state.wallet+=pay;saveWallet();const label=state.betType==='win'?'単勝':'複勝';$('finishList').innerHTML=state.result.map((h,i)=>`<div class="finish-row"><span class="rank">${i+1}着</span><span class="number" style="background:${colors[(h.number-1)%colors.length]};color:${frameTextColor(h.number)}">${h.number}</span><span><b>${escapeHtml(h.name)}</b><span class="horse-meta">${h.style}・事前勝率 ${formatPct(h.winProb)}</span></span><b>${formatTime(h.finish||0)}</b></div>`).join('');$('payout').className=`payout ${hit?'win':'lose'}`;$('payout').innerHTML=hit?`${label} 的中！<strong>+${pay.toLocaleString('ja-JP')} pt</strong>`:`${label} 不的中<strong>-${state.stake.toLocaleString('ja-JP')} pt</strong>1着：${state.result[0].number}番 ${escapeHtml(state.result[0].name)}`}
function formatTime(s){return `${Math.floor(s/60)}:${(s%60).toFixed(1).padStart(4,'0')}`}

function createPeerRoom(){
 if(!window.Peer){alert('オンライン通信を読み込めません。通信環境を確認してください。');return}
 closePeer();state.roomCode=(state.roomCode||String(Math.floor(100000+Math.random()*900000))).toUpperCase();hostPeerAttempts++;$('generateBtn').disabled=true;$('generateBtn').textContent='ルームを作成中…';peer=new Peer(`umauma-${state.roomCode.toLowerCase()}`);
 peer.on('open',()=>{$('generateBtn').disabled=false;$('generateBtn').textContent='ルームを作る';state.mode='online';state.isHost=true;const me={...state.playerProfile};hostRoom={code:state.roomCode,race:{venue:state.venue,going:state.going,race:state.race,seed:state.seed,raceNo:state.raceNo},players:{[me.id]:me}};syncRoomState();renderLobbyPeer()});
 peer.on('connection',conn=>{hostConnections.set(conn.peer,conn);conn.on('data',msg=>handleHostMessage(conn,msg));conn.on('close',()=>{for(const [id,p] of Object.entries(hostRoom?.players||{}))if(p.peerId===conn.peer)delete hostRoom.players[id];syncRoomState();renderLobbyPeer()})});
 peer.on('error',e=>{$('generateBtn').disabled=false;$('generateBtn').textContent='ルームを作る';if(e.type==='unavailable-id'){alert('その合言葉は使用中です。別の合言葉に変更してください。');show('profilePanel')}else alert(`ルーム作成に失敗しました：${e.type}。通信を確認してもう一度押してください。`)});
}
function handleHostMessage(conn,msg){if(msg?.type==='join'){const p={...msg.player,peerId:conn.peer};hostRoom.players[p.id]=p;syncRoomState();renderLobbyPeer()}else if(msg?.type==='leave'){delete hostRoom.players[msg.id];syncRoomState();renderLobbyPeer()}}
function syncRoomState(){if(!hostRoom)return;const packet={type:'room',room:hostRoom};hostConnections.forEach(c=>{if(c.open)c.send(packet)})}
function renderLobbyPeer(){
 const players=Object.values(hostRoom?.players||{});state.roomPlayers=players;state.field=players.map((p,i)=>({...p.horse,number:i+1,ownerId:p.id,ownerName:p.name}));state.selection=[Math.max(1,players.findIndex(p=>p.id===state.userId)+1)];recalculate();show('lobbyPanel');$('roomCodeDisplay').textContent=state.roomCode;renderRoomQr();$('lobbyRaceTitle').textContent=state.race.name;$('lobbyConditions').textContent=`${state.venue} 芝${state.race.distance}m・${state.going}`;$('lobbyProbability').textContent=probabilityText();$('participantList').innerHTML=state.field.map(h=>`<div class="participant"><div><b>${h.number}番 ${escapeHtml(h.name)}</b><span>オーナー：${escapeHtml(h.ownerName)}</span></div><strong>${formatPct(h.winProb)}</strong></div>`).join('');$('hostStartBtn').hidden=!state.isHost;$('hostStartBtn').disabled=players.length<2;
}
async function joinRoom(){
 const p=profileFrom('join'),code=$('roomCodeInput').value.trim().toUpperCase().replace(/[^A-Z0-9]/g,'');if(!p||code.length<4||code.length>12){$('joinMessage').textContent='表示名・馬名・ルーム合言葉を入力し、10ポイントをすべて配分してください。';return}if(!window.Peer){$('joinMessage').textContent='オンライン通信を読み込めません。';return}closePeer();state.playerProfile=p;state.roomCode=code;state.mode='online';state.isHost=false;peer=new Peer();peer.on('open',()=>{const conn=peer.connect(`umauma-${code.toLowerCase()}`,{reliable:true});conn.on('open',()=>{hostConnections.set('host',conn);conn.send({type:'join',player:p});$('joinMessage').textContent='接続しました。'});conn.on('data',handleClientMessage);conn.on('close',()=>{$('joinMessage').textContent='主催者との接続が終了しました。'});setTimeout(()=>{if(!conn.open)$('joinMessage').textContent='ルームが見つからないか、主催者が閉じています。'},7000)});peer.on('error',e=>{$('joinMessage').textContent=`接続エラー：${e.type}`})
}
function handleClientMessage(msg){if(msg?.type==='room'){hostRoom=msg.room;const r=hostRoom.race;state.venue=r.venue;state.going=r.going;state.race=r.race;state.seed=r.seed;state.raceNo=r.raceNo;renderLobbyPeer()}else if(msg?.type==='start'){applyStartPacket(msg);countdownThenRace(msg.startAt)}}
function hostStartOnline(){if(!hostRoom||Object.keys(hostRoom.players).length<2)return;const players=Object.values(hostRoom.players);state.seed=Math.floor(Math.random()*2**31);state.field=players.map((p,i)=>({...p.horse,number:i+1,ownerId:p.id,ownerName:p.name}));state.selection=[Math.max(1,players.findIndex(p=>p.id===state.userId)+1)];recalculate();const packet={type:'start',startAt:Date.now()+4200,seed:state.seed,field:state.field,race:hostRoom.race};hostConnections.forEach(c=>{if(c.open)c.send(packet)});applyStartPacket(packet);countdownThenRace(packet.startAt)}
function applyStartPacket(p){state.seed=p.seed;state.field=p.field;state.race=p.race.race;state.venue=p.race.venue;state.going=p.race.going;const own=state.field.findIndex(h=>h.ownerId===state.userId);state.selection=[own>=0?own+1:1];recalculate();renderOdds()}
function closePeer(){try{peer?.destroy()}catch{}peer=null;hostConnections.clear();hostRoom=null}

function roomJoinUrl(){const u=new URL(location.href);u.searchParams.set('room',state.roomCode||'');return u.toString()}
function renderRoomQr(){const box=$('roomQr');if(!box)return;box.innerHTML='';if(window.QRCode&&state.roomCode)new QRCode(box,{text:roomJoinUrl(),width:150,height:150,correctLevel:QRCode.CorrectLevel.M})}
async function copyRoomCode(){try{await navigator.clipboard.writeText(state.roomCode||'');$('copyRoomBtn').textContent='コピー済み';setTimeout(()=>$('copyRoomBtn').textContent='合言葉をコピー',1200)}catch{alert(`合言葉：${state.roomCode}`)}}
async function shareRoomLink(){const data={title:'川上ウマウマレース',text:`ルーム「${state.roomCode}」に参加して！`,url:roomJoinUrl()};try{if(navigator.share)await navigator.share(data);else{await navigator.clipboard.writeText(data.url);alert('参加リンクをコピーしました')}}catch{}}
function applyRoomFromUrl(){const code=(new URL(location.href)).searchParams.get('room');if(!code)return;$('roomCodeInput').value=code.toUpperCase();setTimeout(()=>show('joinPanel'),50)}

function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
init();
